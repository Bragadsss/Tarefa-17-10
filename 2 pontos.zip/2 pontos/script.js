let produtosDisponiveis = [
  { nome: 'Camisa', preco: 50, quantidade: 10 },
  { nome: 'Calça', preco: 100, quantidade: 5 },
  { nome: 'Sapato', preco: 150, quantidade: 3 },
  { nome: 'Cinto', preco: 20, quantidade: 15 },
  { nome: 'Boné', preco: 30, quantidade: 7 }
];

let carrinho = [];

function adicionarAoCarrinho(nomeProduto) {
  let produto = produtosDisponiveis.find(produto => produto.nome === nomeProduto);
  
  if (produto && produto.quantidade > 0) {
    carrinho.push(produto);
    produto.quantidade--; 
    atualizarCarrinho();
    atualizarTotal();
  } else {
    alert('Produto esgotado ou não encontrado.');
  }
}

function removerDoCarrinho(indice) {
  let produtoRemovido = carrinho.splice(indice, 1)[0];
  
  
  let produtoOriginal = produtosDisponiveis.find(produto => produto.nome === produtoRemovido.nome);
  produtoOriginal.quantidade++;
  
  atualizarCarrinho();
  atualizarTotal();
}

function ordenarCarrinhoPorPreco() {
  carrinho.sort((a, b) => b.preco - a.preco); 
  atualizarCarrinho();
}

function atualizarCarrinho() {
  let carrinhoDiv = document.getElementById('carrinho');
  carrinhoDiv.innerHTML = ''; 
  
  carrinho.forEach((produto, indice) => {
    carrinhoDiv.innerHTML += `
      <p>${produto.nome} - R$ ${produto.preco.toFixed(2)}
      <button class="remover-button" onclick="removerDoCarrinho(${indice})">Remover</button></p>
    `;
  });
}

function atualizarTotal() {
  let total = carrinho.reduce((acumulador, produto) => acumulador + produto.preco, 0);
  document.getElementById('total').innerText = `R$ ${total.toFixed(2)}`;
}

function finalizarCompra() {
  if (carrinho.length > 0) {
    
    window.location.assign('felicitacoes.html');
  } else {
    alert('Seu carrinho está vazio! Adicione produtos antes de comprar.');
  }
}
function finalizarCompra() {
  if (carrinho.length > 0) {
    
    sessionStorage.setItem('carrinho', JSON.stringify(carrinho));
    let total = carrinho.reduce((acumulador, produto) => acumulador + produto.preco, 0);
    sessionStorage.setItem('total', total);
    
    window.location.assign('felicitacoes.html');
  } else {
    alert('Seu carrinho está vazio! Adicione produtos antes de comprar.');
  }
}
